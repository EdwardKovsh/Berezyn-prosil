#include <iostream>
#include <windows.h>

using namespace std;

void gotoxy(int x, int y)
{
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

int main()
{
    cout << "Hello world!" << endl;
    gotoxy(0, 0);
    Sleep(2000);
    cout << "Ok by now." << endl;
    return 0;
}
